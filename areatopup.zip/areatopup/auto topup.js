// areatopup-backend/index.js

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const mysql = require('mysql2');
const axios = require('axios');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = 'areatopup-jwt-secret';

app.use(cors());
app.use(bodyParser.json());

// MySQL Connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'areatopup_db'
});

db.connect(err => {
  if (err) throw err;
  console.log('MySQL Connected');
});

// Middleware Auth
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

// Routes

// Admin Login (JWT)
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  const sql = 'SELECT * FROM admin WHERE email = ? AND password = ?';
  db.query(sql, [email, password], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    if (result.length > 0) {
      const user = { id: result[0].id, email: result[0].email };
      const token = jwt.sign(user, JWT_SECRET, { expiresIn: '2h' });
      res.json({ token });
    } else {
      res.status(401).json({ message: 'Login gagal' });
    }
  });
});

// Get Harga dari API Vendor
app.get('/api/harga', async (req, res) => {
  try {
    const response = await axios.get('https://api.vendor.com/pricelist?api_key=APIKAMU');
    const data = response.data;
    const filtered = data.filter(item => item.game === 'Mobile Legends');
    res.json(filtered);
  } catch (error) {
    res.status(500).json({ error: 'Gagal ambil harga' });
  }
});

// Checkout (Keranjang)
app.post('/api/checkout', async (req, res) => {
  const { items, nama, metode } = req.body;
  // items = [{id, name, price, qty}]
  try {
    // Simpan ke database jika diperlukan atau kirim email/kode topup
    res.json({ message: 'Checkout berhasil', total: items.reduce((acc, item) => acc + item.price * item.qty, 0) });
  } catch (err) {
    res.status(500).json({ error: 'Checkout gagal' });
  }
});

// Admin-only route example
app.get('/api/admin/pesanan', authenticateToken, (req, res) => {
  db.query('SELECT * FROM pesanan ORDER BY id DESC', (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json(result);
  });
});

app.listen(PORT, () => {
  console.log(`Server berjalan di http://localhost:${PORT}`);
});
