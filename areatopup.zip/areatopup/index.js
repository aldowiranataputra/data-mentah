const axios = require('axios');

app.get('/api/harga', async (req, res) => {
  try {
    const response = await axios.get('https://api.vendor.com/pricelist?api_key=APIKAMU');
    const data = response.data;
    // Ambil data yang dibutuhkan
    const filtered = data.filter(item => item.game === 'Mobile Legends');
    res.json(filtered);
  } catch (error) {
    res.status(500).json({ error: 'Gagal ambil harga' });
  }
});
