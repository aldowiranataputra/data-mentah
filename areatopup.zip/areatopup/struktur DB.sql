CREATE DATABASE areatopup_db;

USE areatopup_db;

CREATE TABLE admin (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(100),
  password VARCHAR(100)
);

CREATE TABLE pesanan (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100),
  id_game VARCHAR(100),
  game VARCHAR(100),
  nominal VARCHAR(100),
  metode VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO admin (email, password) VALUES ('admin@areatopup.com', 'admin123');
