GET https://api.vendor.com/pricelist?api_key=YOUR_API_KEY
