import React, { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function LandingPage() {
  const [games, setGames] = useState([]);
  const [cart, setCart] = useState([]);
  const [adminToken, setAdminToken] = useState(localStorage.getItem('token') || '');
  const [showLogin, setShowLogin] = useState(false);
  const [loginForm, setLoginForm] = useState({ email: '', password: '' });

  useEffect(() => {
    fetch("http://localhost:3000/api/harga")
      .then((res) => res.json())
      .then((data) => setGames(data))
      .catch((err) => console.error(err));
  }, []);

  const addToCart = (item) => {
    setCart((prev) => [...prev, { ...item, qty: 1 }]);
  };

  const total = cart.reduce((acc, item) => acc + item.price * item.qty, 0);

  const handleCheckout = async () => {
    const nama = prompt("Masukkan nama Anda");
    const metode = prompt("Masukkan metode pembayaran (OVO/DANA/Bank)");
    const res = await fetch("http://localhost:3000/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nama, metode, items: cart }),
    });
    const data = await res.json();
    alert(data.message + " | Total: Rp" + data.total.toLocaleString());
    setCart([]);
  };

  const handleLogin = async () => {
    const res = await fetch('http://localhost:3000/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(loginForm),
    });
    const data = await res.json();
    if (data.token) {
      localStorage.setItem('token', data.token);
      setAdminToken(data.token);
      alert('Login sukses');
      setShowLogin(false);
    } else {
      alert(data.message || 'Login gagal');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setAdminToken('');
  };

  return (
    <div className="p-4 max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-3xl font-bold text-blue-600">AreaTopup.com</h1>
        {adminToken ? (
          <Button onClick={handleLogout} className="bg-red-600 hover:bg-red-700">Logout Admin</Button>
        ) : (
          <Button onClick={() => setShowLogin(true)}>Login Admin</Button>
        )}
      </div>

      {showLogin && (
        <div className="bg-white p-4 rounded-xl shadow-md max-w-md mx-auto mb-4">
          <h2 className="text-lg font-semibold mb-2">Login Admin</h2>
          <input
            type="email"
            placeholder="Email"
            className="w-full p-2 border rounded mb-2"
            value={loginForm.email}
            onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
          />
          <input
            type="password"
            placeholder="Password"
            className="w-full p-2 border rounded mb-2"
            value={loginForm.password}
            onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
          />
          <Button className="w-full" onClick={handleLogin}>Login</Button>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {games.map((item) => (
          <Card key={item.id} className="rounded-2xl shadow-md">
            <CardContent className="p-4">
              <h2 className="font-semibold text-lg">{item.name}</h2>
              <p className="text-sm text-gray-600">{item.game}</p>
              <p className="text-blue-500 font-bold mt-2">Rp{item.price.toLocaleString()}</p>
              <Button className="mt-3 w-full" onClick={() => addToCart(item)}>Tambah</Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {cart.length > 0 && (
        <div className="mt-8 p-4 border rounded-xl bg-white shadow-lg">
          <h2 className="text-xl font-bold mb-2">🛒 Keranjang</h2>
          {cart.map((item, index) => (
            <div key={index} className="flex justify-between py-1">
              <span>{item.name} x{item.qty}</span>
              <span>Rp{(item.price * item.qty).toLocaleString()}</span>
            </div>
          ))}
          <div className="font-semibold mt-2">Total: Rp{total.toLocaleString()}</div>
          <Button className="mt-4 w-full bg-green-600 hover:bg-green-700" onClick={handleCheckout}>Checkout</Button>
        </div>
      )}
    </div>
  );
}
